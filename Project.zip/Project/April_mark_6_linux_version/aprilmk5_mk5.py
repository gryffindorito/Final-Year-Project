import speech_recognition as sr
import sys
import time
from time import ctime
import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import random
import pygame 

pygame.mixer.init()
"""
pygame.mixer.music.load("alarm_tone.mp3")
pygame.mixer.music.set_volume(1.0)
pygame.mixer.music.play()
while pygame.mixer.music.get_busy() == True:
	pass
"""
