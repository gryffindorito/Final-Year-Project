import os
os.system('./speak.sh "Yes ?"')
