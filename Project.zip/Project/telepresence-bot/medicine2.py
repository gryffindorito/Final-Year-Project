from flask import Flask, render_template, request,redirect,url_for
import sqlite3 as sql
app = Flask(__name__)

msg=""

@app.route('/')
def home():
   con = sql.connect("medicine.db")
   con.row_factory = sql.Row
   
   cur = con.cursor()
   cur.execute("select * from details")
   
   rows = cur.fetchall();
   return render_template('medicine.html',msg=msg,rows=rows)

@app.route('/entry',methods = ['POST', 'GET'])
def entry():
   if request.method == 'POST':
      try:
         sno=0
         name = request.form['name']
         time = request.form['time']
         dose = request.form['dose']
         with sql.connect("medicine.db") as con:
            cur = con.cursor()
            cur.execute("SELECT * FROM details")
            rows=cur.fetchall()
            for i in rows:
               sno+=1
            sno+=1
            print sno,name,time,dose
            print "entering data"
            cur.execute("INSERT INTO details (sno,name,time,dose) VALUES (?,?,?,?)",(sno,name,time,dose) )
            print "executing"
            con.commit()
            print "commit"
            msg = "Record successfully added"
      except:
         con.rollback()
         msg = "error in insert operation"
      
      finally:
         con = sql.connect("medicine.db")
         con.row_factory = sql.Row
         
         cur = con.cursor()
         cur.execute("select * from details")
         
         rows = cur.fetchall();
         return redirect(url_for('home'))
         con.close()

@app.route('/update',methods = ['POST', 'GET'])
def update():
   if request.method == 'POST':
      try:
         sno = request.form['sno']
         name = request.form['name']
         time = request.form['time']
         dose = request.form['dose']
         print name,time,dose
         with sql.connect("medicine.db") as con:
            cur = con.cursor()
            print "entering data"
            cur.execute("UPDATE details SET name=?, time=? , dose=? WHERE sno=?",(name,time,dose,sno) )
            print "executing"
            con.commit()
            print "commit"
            msg = "Record successfully updated"
      except:
         con.rollback()
         msg = "error in insert operation"
      
      finally:
         con = sql.connect("medicine.db")
         con.row_factory = sql.Row
         
         cur = con.cursor()
         cur.execute("select * from details")
         
         rows = cur.fetchall();
         return redirect(url_for('home'))
         con.close()

@app.route('/remove',methods = ['POST', 'GET'])
def remove():
   if request.method == 'POST':
      try:
         sno = request.form['sno']
         with sql.connect("medicine.db") as con:
            cur = con.cursor()
            print "removing data"
            cur.execute("DELETE FROM details WHERE sno=?",(sno) )
            print "executing"
            con.commit()
            print "commit"
            msg = "Record successfully deleted"
      except:
         con.rollback()
         msg = "error in delete operation"
      
      finally:
         con = sql.connect("medicine.db")
         con.row_factory = sql.Row
         
         cur = con.cursor()
         cur.execute("select * from details")
         
         rows = cur.fetchall();
         return redirect(url_for('home'))
         con.close()

@app.route('/list')
def list():
   con = sql.connect("medicine.db")
   con.row_factory = sql.Row
   
   cur = con.cursor()
   cur.execute("select * from details")
   
   rows = cur.fetchall();
   return render_template("list.html",rows = rows)

if __name__ == '__main__':
   app.run(debug = True,host="0.0.0.0",port=7070)
