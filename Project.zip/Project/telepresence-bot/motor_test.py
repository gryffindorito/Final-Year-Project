import RPi.GPIO as GPIO # Import Raspberry Pi GPIO library
from time import sleep # Import the sleep function from the time module
GPIO.setwarnings(False) # Ignore warning for now
GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
GPIO.setup(16, GPIO.OUT, initial=GPIO.LOW)#right
GPIO.setup(18, GPIO.OUT, initial=GPIO.LOW)#right
GPIO.setup(13, GPIO.OUT, initial=GPIO.LOW)#left 
GPIO.setup(15, GPIO.OUT, initial=GPIO.LOW)#left
GPIO.output(16, GPIO.LOW)#a2
GPIO.output(18, GPIO.HIGH)#a1
GPIO.output(13, GPIO.HIGH)#b2
GPIO.output(15, GPIO.LOW)#b1
sleep(1)
GPIO.output(16, GPIO.HIGH)#a2
GPIO.output(18, GPIO.LOW)#a1
GPIO.output(13, GPIO.LOW)#b2
GPIO.output(15, GPIO.HIGH)#b1
sleep(1)
GPIO.output(16, GPIO.HIGH)#a2
GPIO.output(18, GPIO.LOW)#a1
GPIO.output(13, GPIO.HIGH)#b2
GPIO.output(15, GPIO.LOW)#b1
sleep(1)
GPIO.output(16, GPIO.LOW)#a2
GPIO.output(18, GPIO.LOW)#a1
GPIO.output(13, GPIO.LOW)#b2
GPIO.output(15, GPIO.LOW)#b1
