from subprocess import check_output
x=check_output(['hostname', '-I'])
ip=x.split()
print ip[0]
