lxterminal -e python /home/pi/telepresence-bot/bot.py
lxterminal -e python /home/pi/telepresence-bot/controls.py
lxterminal -e python /home/pi/telepresence-bot/main_CandC.py
lxterminal -e python /home/pi/telepresence-bot/Home.py
lxterminal -e python /home/pi/telepresence-bot/medicine2.py
lxterminal -e python /home/pi/April_mark_6_linux_version/aprilmk5_mk6.py
lxterminal -e python /home/pi/April_mark_6_linux_version/medicine_alert.py
